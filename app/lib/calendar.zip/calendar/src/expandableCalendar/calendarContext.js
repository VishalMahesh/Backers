import React from 'react';

const CalendarContext = React.createContext({});
export default CalendarContext;
